

package Pertemuan3;

import java.util.Scanner;
public class PercabanganIf {
    
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        System.out.println("Apakah bentuk bumi itu ? ");
        String jawaban = input.next();
        
        if(jawaban.equals("bulat")){
            System.out.println("Jawaban anda benar");
        }
        }
    }

