/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pertemuan3;

/**
 *
 * @author hp
 */
import java.util.Scanner;
public class Percabangan_ifelse {
    public static void main(String[] args) {
       Scanner input = new Scanner(System.in);
      System.out.println("pilih antara 1 & 2 untk menentukan apa jenis kelaminnya elna?  ");
            
        int pilih = input.nextInt();

        if (pilih == 1) {
            System.out.println("cewek");
        } else {
            System.out.println("cewek");
            
       
        }  
    }


}
