/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pertemuan3;
import java.util.Scanner;
/**
 *
 * @author hp
 */
public class Percabangan__Switch_Case {
    public static void main(String[] args) {
        Scanner ubg = new Scanner(System.in);
        
        System.out.println("-----------");
        System.out.println("Menu Makanan");
        System.out.println("1. Ayam Bakar ");
        System.out.println("2. Babi Guling ");
        System.out.println("1. Nasi Kuning ");
        System.out.println("----------");
        
        System.out.println("Masukkan Menu : ");
        int menu = ubg.nextInt();
        switch(menu){
            case 1:
                System.out.println("Ayam Bakar : Rp 15.000");
            break;
            case 2 :
                System.out.println("Babi Guling : Rp 50.000");
            break;
            case 3 :
                System.out.println("Nasi kuning : Rp 12.000");
            break;
            default:
                System.out.println("Menu tidak Tersedia");
        }
        
    }
}
