/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pertemuan3;

/**
 *
 * @author hp
 */
import java.util.Scanner;
public class Latihan_IfElse {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
      System.out.println("Berapa Nilai UAS ? ");
            
        int pilih = input.nextInt();

        if (pilih > 50) {
            System.out.println("Anda Lulus");
        } else {
   
            System.out.println("Anda Tidak Lulus");
    }
    }
}
