/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pertemuan3;

import java.util.Scanner;

/**
 *
 * @author hp
 */
public class elseif {
      public static void main(String[] args) {
       Scanner ubg = new Scanner(System.in);
       int nilai;
       String grade;
       System.out.print("Cek Nilai Akhir: ");
       nilai = ubg.nextInt();
       if ((nilai >= 50)&&(nilai <= 59)) {
           grade = "C";
       }else if ((nilai >= 60)&&(nilai <= 69)) {
          grade = "C+";
       }else if ((nilai >= 70)&&(nilai <= 79)) {
          grade = "B";
       }else if ((nilai >= 80)&&(nilai <= 89)) {
          grade = "B+"; 
       }else if ((nilai >= 90)&&(nilai <= 100)) {
          grade = "A+"; 
       }else {
          grade = "D";
       } 
       System.out.println("Grade: "+ grade);
      
     }
}
