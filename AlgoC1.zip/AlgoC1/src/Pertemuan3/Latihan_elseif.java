/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pertemuan3;

/**
 *
 * @author hp
 */
import java.util.Scanner;
public class Latihan_elseif {
    public static void main(String[] args) {
       Scanner ubg = new Scanner(System.in);
       double nilai;
       String grade;
       System.out.print("Nilai Akhir: ");
       nilai = ubg.nextDouble();
       if ((nilai >= 91)&&(nilai <= 100)) {
           grade = "A";
       }else if ((nilai >= 81)&&(nilai <= 90)) {
          grade = "B";
       }else if ((nilai >= 71)&&(nilai <= 80)) {
          grade = "C";
       }else if ((nilai >= 61)&&(nilai <= 70)) {
          grade = "D"; 
       }else {
          grade = "E";
       } 
       System.out.println("Grade: "+ grade);
    }
    
 }

