/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pertemuan3;

import java.util.Scanner;

/**
 *
 * @author Adiand An
 */
public class Latihan_switch_case {
    public static void main(String[] args) {
        Scanner Limin = new Scanner(System.in);
        int Ngaha_bakso;
        System.out.println("menu Bakso nee ndaim: "
                + "\n1. ma waru riwu"
                + "\n2. ma sempuru riwu"
                + "\n3. ma sempuru lima riwu"
                + "\n----------------------");
        System.out.print("Nee ma pila ke : ");
        Ngaha_bakso = Limin.nextInt();
        switch(Ngaha_bakso){
            case 1 :
                System.out.println("Bakso waru riwu labo\npangsit siap dibuat");
                break;
            case 2 :
                System.out.println("Bakso sempuru riwu labo\nceker sedang dibuat");
                break;
            case 3 :
                System.out.println("Bakso sempuru lima riwu\nma jumbo sedang dibuat");
                break;
            default :
                System.out.println("Tiwara menu ede kawan");
             
            }
    }
    
}
