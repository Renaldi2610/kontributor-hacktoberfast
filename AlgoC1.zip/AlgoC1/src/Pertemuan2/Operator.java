/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pertemuan2;

import java.util.Scanner;

/**
 *
 * @author hp
 */
public class Operator {
    public static void main(String[] args) {
        System.out.println("-----"+ "TUGAS OPERATOR" + "-----");
        System.out.println("Nama  : M. Rizki" + "\nKelas : C1" + "\nNim   : 2101010115");
        
        
        
        System.out.println("\nOPERATOR ARITMATIKA");
        Scanner input = new Scanner(System.in); 
        System.out.print("Masukkan Nilai A : ");
        int nilaiA = input.nextInt();
        System.out.print("Masukkan Nilai B : ");
        int nilaiB = input.nextInt();

        System.out.println("Nilai A : " + nilaiA);
        System.out.println("Nilai B : " + nilaiB);
        
        int hasil_tambah = nilaiA + nilaiB;
        int hasil_kurang = nilaiA - nilaiB;
        int hasil_kali = nilaiA * nilaiB;
        int hasil_bagi = nilaiA / nilaiB;
        int hasil_sisa_bagi = nilaiA % nilaiB;
        System.out.println("Hasil Penambahan : " + hasil_tambah);
        System.out.println("Hasil Pengurangan : " + hasil_kurang);
        System.out.println("Hasil Perkalian : " + hasil_kali);
        System.out.println("Hasil Pembagian : " + hasil_bagi);
        System.out.println("Hasil Pembagian : " + hasil_sisa_bagi);
        
        System.out.println("\nOPERATOR PENUGASAN");
        //Penugasan operator Jumlah
        int a = 10;
        System.out.println("nilai a : " + a);
        a += 12; // a = a + 12
        System.out.println("nilai a += 12 : " + a);
        //Penugasan operator Pengurangan
        int b = 10;
        System.out.println("nilai b : " + b);
        b -= 12; // b = b - 12
        System.out.println("nilai b -= : " + b);
        //Penugasan operator Perkalian
        int c = 100;
        System.out.println("nilai c : " + c);
        c *= 10; // c = c * 10
        System.out.println("nilai c *= 10 : " + c);
        //Penugasan operator Pembagian
        int d = 100;
        System.out.println("nilai d: " + d);
        d /= 25; // d = d / 25
        System.out.println("nilai d /= 25 : " + d);
        //Penugasan operator Modulus/ Sisa bagi
        int e = 10;
        System.out.println("nilai e : " + e);
        e %= 7 ;  // e = e % 7
        System.out.println("nilai e %= 7  : " + e);
        
        int A = 9;
        int B = 15;
        boolean hasil;

        System.out.println("\nOPERATOR PEMBANDING");
        System.out.println("Nilai A = " + A + " Dan Nilai B = " + B );
        
        // apakah A lebih besar dari B?
        hasil = A > B;  
        System.out.println("A lebih besar dari B : "+hasil);

        // apakah A lebih kecil dari B?
        hasil = A < B;
        System.out.println("A Lebih Kecil dari B : "+hasil);

        // apakah A lebih besar samadengan B?
        hasil = A >= B;
        System.out.println("A lebih Besar atau sama dengan B : "+hasil);

        // apakah A lebih kecil samadengan B?
        hasil = A <= B;
        System.out.println("A Lebih kecil atau sama dengan B : "+hasil);

        // apakah nilai A sama dengan B?
        hasil = A == B;
        System.out.println("A sama dengan B : " + hasil);

        // apakah nilai A tidak samadengan B?
        hasil = A != B;
        System.out.println("A tidak sama dengan B :"+ hasil);
        
        System.out.println("\nOPERATOR LOGIKA");
        boolean p = true ;
        boolean q = false ;
        boolean r ;
        //konjungsi (dan)
        r = p && q;
        System.out.println("true && false : "+r);
        //disjungsi (atau)
        r = p || q;
        System.out.println("true || false : "+ r);
        //negasi (bukan)
        r = !p;
        System.out.println("Negasi dari true :  "+ r);
        r = !q;
        System.out.println("Negasi dari false : "+ r);
        
        System.out.println("\nOPERATOR BITWISE");
        int J = 60;    /* 60 = 0011 1100 */
        int K = 13;    /* 13 = 0000 1101 */
        int L ;
        
        System.out.println("Nilai J :     "+ J + " bin : 0011 1100 \nDan NILAI K : " + K + " bin : 0000 1101");
        
        L = J & K;       /* 12 = 0000 1100 */
        System.out.println("J & K = " + L);

        L = J | K;       /* 61 = 0011 1101 */
        System.out.println("J | K = " + L);

        L = J ^ K;       /* 49 = 0011 0001 */
        System.out.println("J ^ K = " + L);

        L = ~J;          /*-61 = 1100 0011 */
        System.out.println("~J = " + L);

        L = J << 2;     /* 240 = 1111 0000 */
        System.out.println("J << 2 = " + L);

        L = J >> 2;     /* 215 = 1111 */
        System.out.println("J >> 2  = " + L);

        L = J >>> 2;     /* 215 = 0000 1111 */
        System.out.println("J >>> 2 = " + L);
        
        System.out.println("\nOPERATOR TERNARY");
        boolean suka = true;
        String Answer ;
        
        // menggunakan operator ternary
        Answer = suka ? "Kepedihan terburuk adalah ketika kamu tidak ingin menyerah pada seseorang,\n tetapi kamu tahu kamu harus melakukannya . \n -Iky,12-10-21" : "tidak ada";
        
        //menampilkan jawaban
        System.out.println(" Apakah kepedihan yang pernah kamu rasakan di dunia ini?\n "+ Answer);
        
        boolean benci = false;
        String jawaban ;
        
        jawaban = benci ? "iya" : "tidak";
        System.out.println("\nbenci dia? " + jawaban);
        
    }
}
